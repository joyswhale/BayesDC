#' @title A dataset of simulated quantitative trait and two SNPs.
#'
#' @description The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex. The six five column is quantitative trait, and seven and eight is tow SNPs.
#'
#' @docType data
#' @keywords datasets
#' @name ped1
#' @usage ped1
#' @format A dataset for 1,000 unrelated  subjects and eight variables.
#' \describe{
#' \item{FID}{Pedigree ID.}
#' \item{IID}{Individual ID.}
#' \item{PID}{Father ID.}
#' \item{MID}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{phen}{A numeric variable of the quantitative trait.}
#' \item{geno1}{A numeric variable of code of SNP. Each genotype is coded as 0, 1 or 2 for female and 0, 2 for male, indicating the number of the minor alleles.}
#' \item{geno2}{A numeric variable of code of SNP. Each genotype is coded as 0, 1 or 2 for female and 0, 2 for male, indicating the number of the minor alleles.}
#' }
NULL
