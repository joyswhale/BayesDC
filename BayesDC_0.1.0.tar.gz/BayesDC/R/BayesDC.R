#' @title The Bayesian method for estimating the degree of the dosage compensation on X chromosome 
#' @description This code contains the Bayesian method for estimating the degree of the dosage compensation on X chromosome (denoted as \eqn{\d}) for either quantitative traits or qualitative traits, with or without covariates using unrelated subjects.
#' @usage BayesDC(ped,covariate=NULL,trait_type,
#'                trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'                 prior,chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'
#' @param ped The data frame "ped" contains the following information: pedigree ID (FID), individual ID (IID), father’s ID (PID), mother’s ID (MID), sex, phenotype, genotypes. Either father’s or mother’s ID is set to 0 for founders, i.e. individuals with no parents. Numeric coding for sex is 0 = unknown, 1 = male, 2 = female. Each genotype is coded as 0, 1 or 2 for female and 0, 2 for male, indicating the number of the minor alleles. For quantitative traits, phenotypes are individuals’ trait values. Numeric coding for a qualitative trait is 1 = unaffected, 2 = affected. The ped provided to this function should only contain SNPs on X chromosome.
#' @param covariate The covariates needed to be adjusted, can be a txt file or a dataframe/matrix, the first five columns should be pedigree ID (FID), individual ID (IID), father’s ID (PID), mother’s ID (MID), sex.
#' @param trait_type A character string either being "quantitative" or "qualitative", indicating the type of the trait.
#' @param trait_missing The input variable "trait_missing" is the missing value for the trait in the data file, and the default value is NA. It may be 9 in some data files; or other numeric value.
#' @param genotype_missing The input variable "genotype_missing" represents that the allele at the locus is missing, and the default value is 0. It may be 9 in some data files; or other numeric value.
#' @param covariate_missing The input variable "covariate_missing" is the missing value for the covariates in the data file, and the default value is NA.
#' @param prior A character string either being "normal" or "uniform". "prior"="normal" represents that the prior distribution of \eqn{\d} is a truncated normal distribution with mean=2 and sd=1, and the values ranging from 1/4 to 4, and the prior distributions of other unknown parameters are consistent with those proposed in the paper; "prior"="uniform" represents that the prior distribution of \eqn{\d} is the uniform distribution specified in our paper, that is, \eqn{\gamma}~U(1/4, 4), and the prior distributions of other unknown parameters are consistent with those proposed in the paper.
#' @param chains_num A positive integer specifying the number of the Markov chains. The default number is 8.
#' @param iter_num A positive integer specifying the number of the iterations for each chain (including warmup). The default number is 3,000.
#' @param warmup_num A positive integer specifying the number of the warmup (also known as burnin) iterations per chain. The number of the warmup iterations should be smaller than the number of the iterations and the default is 1,000.
#' @param acceptance_rate A value between 0 and 1 which represents the target acceptance rate, and the default is 0.99.
#' 
#' @details Please install the "rstan" package and make sure that it can work before using this function. Note that we estimate the degree of the dosage compensation on X chromosome in the presence of association. The results may be different for different runs, because of the sampling randomness of the HMC algorithm. If the fixed results are wanted, the seed number should be set before running the function. Note that different version of R may lead to different results under the same seed number. The results of the examples given in this file are obtained under the R with version 4.1.2. Meanwhile, we recommend using "chains_num"=8, "iter_num"=3,000, "warmup_num"=1,000 and "acceptance_rate"=0.99 in practical applications.
#'
#' @return
#' \item{Point_Estimate}{The point estimate of the degree of the dosage compensation on X chromosome for the SNP based on the Bayesian method.}
#' \item{HPDI_Lower}{The lower bound of the HPDI.}
#' \item{HPDI_Upper}{The upper bound of the HPDI.}
#' @export
#' 
#' @references  Yi Zhang. Bayesian methods for estimating the degree of dosage compensation on X chromosome. 2025
#' @references Annis, J.; Miller, B. J.; Palmeri, T. J. Bayesian inference with Stan: A tutorial on adding custom distributions. Behav. Res. Methods 2017, 49, 863-886.
#' @author Yi Zhang and Ji-Yuan Zhou
#'
#' @examples
#' #install.package("rstan")
#' library("rstan")
#' options(mc.cores = parallel::detectCores())
#' rstan_options(auto_write = TRUE)
#' 
#' ##example 1:
#' ##quantitative trait with covariate
#' ##the prior distribution of d is a truncated normal distribution specified in our paper
#' set.seed(123)
#'BayesDC(ped1,covariate=covar,trait_type = "quantitative",
#'        trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'        prior = "normal",chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'
#' ##example 2:
#' ##quantitative trait with covariate
#' ##the prior distribution of d is a uniform distribution specified in our paper
#' ##the prior distributions of other unknown parameters are consistent with those in our paper
#' set.seed(123)
#'BayesDC(ped1,covariate=covar,trait_type = "quantitative",
#'        trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'        prior = "uniform",chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'        
#' ##example 3:
#' ##quantitative trait without covariate
#' ##the prior distribution of d is a truncated normal distribution specified in our paper
#' set.seed(123)
#'BayesDC(ped1,covariate=NULL,trait_type = "quantitative",
#'        trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'        prior = "normal",chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'        
#' ##example 4:
#' ##qualitative trait with covariate
#' ##the prior distribution of d is a truncated normal distribution specified in our paper
#' set.seed(123)
#'BayesDC(ped2,covariate=covar,trait_type = "qualitative",
#'        trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'        prior = "normal",chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'        
#' ##example 5:
#' ##qualitative trait with covariate
#' ##the prior distribution of d is a uniform distribution specified in our paper
#' set.seed(123)
#'BayesDC(ped2,covariate=covar,trait_type = "qualitative",
#'        trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'        prior = "uniform",chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'        
#' ##example 6:
#' ##qualitative trait without covariate
#' ##the prior distribution of d is a uniform distribution specified in our paper
#' set.seed(123)
#'BayesDC(ped2,covariate=NULL,trait_type = "qualitative",
#'        trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
#'        prior = "uniform",chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99)
#'        
#'        


BayesDC <- function(ped,covariate=NULL,trait_type,
                    trait_missing=NA,genotype_missing=NA,covariate_missing=NA,
                    prior,chains_num=8,iter_num=3000,warmup_num=1000,acceptance_rate=0.99){
  
  #For pretreatment of covariate
  num_cov <- ncol(covariate)-5
  
  if(!is.null(covariate)){
    
    covariate <- as.matrix(covariate)
    
    covariate_name <- paste('covariate',1:(ncol(covariate)-5),sep='_')
    
    colnames(covariate)[6:(5+num_cov)] <- c(covariate_name)
      
    }

  if(!is.na(covariate_missing)){  
      
      for(i in 1:num_cov){
        
        covariate[which(covariate[,5+i] == covariate_missing),(5+i)] <- NA		
        
      }
    }
    
  ped <- as.matrix(ped)
  
  if(!is.na(trait_missing)){
    
    ped[which(ped[,6] == trait_missing),6] <- NA	
    
  }
  
  # merge ped and covariate if covariate is available
  
  if(!is.null(covariate)){
    
    merge_data <- merge(ped,covariate,by.x="IID",by.y="IID")
    
    merge_data1<-merge_data[order(merge_data[,1]),]
    
    ped <- merge_data1[,1:ncol(ped)]
    
    covariate <- merge_data1[,c(1,(ncol(ped)+1):ncol(merge_data1))]
  }
  
  n.loci <- NCOL(ped)-6
  
  marker.name <- colnames(ped)[6+(1:n.loci)]
    

  # for each loci
  
  Mode_DCd <- NULL
  HPDI_DCd <- NULL   
  
  
  for(i in 1:n.loci){
    
    j <- i+6
    
    if(!is.na(genotype_missing)){  
      
      ped[which(ped[,j] == genotype_missing),j] <- NA	
      
    }
    
    if(!is.null(covariate)){
      
      data <- na.omit(cbind(ped[,c(5,6,j)],covariate[,6:(5+num_cov)]))
      
      data<-matrix(as.numeric(as.matrix(data)),dim(data)[1])
      
      COV<-data[,4:ncol(data)]
      
    }else{
      
      data <- na.omit(ped[,c(5,6,j)])
      
      data<-matrix(as.numeric(data),dim(data)[1])
    }
    
    N<-dim(data)[1]
    
    genotype <- data[,3]
    
    sex <- data[,1]
    
    # three indicator function
    gg_1 <- ifelse(((genotype>=1)&(sex==0)),1,0)
    gg_2 <- ifelse(((genotype==2)&(sex==0)),1,0)
    gg_m <- ifelse(((genotype==1)&(sex==1)),1,0)
    

    # Bayesian model
    if(trait_type=="quantitative"){
      if(is.null(covariate)){
        model_matrix1 = matrix(c(ifelse(sex==0&genotype==0,1,0),
                                ifelse(sex==0&genotype==1,1,0),
                                ifelse(sex==0&genotype==2,1,0),
                                ifelse(sex==1&genotype==0,1,0),
                                ifelse(sex==1&genotype==1,1,0)),N,5)
        
        dataList <- list( N=N,
                      y=data[,2], 
                      sex = sex,
                      gg_1 = gg_1,
                      gg_2 = gg_2,
                      gg_m = gg_m,  
                      n_sigma=5, 
                      model_matrix=model_matrix1 )
        
        if(prior == "normal"){
          modelString = "
        data {
            int<lower=0> N ;
            vector[N] y;
            vector[N] sex;
            vector[N] gg_1;
            vector[N] gg_2;
            vector[N] gg_m;
            int<lower=0> n_sigma;
            matrix[N,n_sigma] model_matrix;
        }
        parameters {
            real beta_0;
            real beta_sex;
            real beta_c;
            real<lower=0,upper=2> gamma;
            real<lower=0.25,upper=4> DCd;
            vector<lower=0>[n_sigma] sigma;
        }
        model {
            vector[N] theta;
            vector[N] sigma_heter;
            theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m;   
            sigma_heter = model_matrix * sigma;
            target += normal_lpdf( beta_0 | 0, 10 );      
            target += normal_lpdf( beta_sex | 0, 10 );
            target += normal_lpdf( beta_c | 0, 10 );
            target += normal_lpdf( gamma | 1, 1 );
            target += normal_lpdf( DCd | 2, 1 );
            target += exponential_lpdf(sigma | 1);
            for(i in 1:N)
              target += normal_lpdf( y[i] | theta[i], sigma_heter[i] );  
        }"
        }
        else if(prior == "uniform"){
          modelString = "
        data {
            int<lower=0> N ;
            vector[N] y;
            vector[N] sex;
            vector[N] gg_1;
            vector[N] gg_2;
            vector[N] gg_m;
            int<lower=0> n_sigma;
            matrix[N,n_sigma] model_matrix;
        }
        parameters {
            real beta_0;
            real beta_sex;
            real beta_c;
            real<lower=0,upper=2> gamma;
            real<lower=0.25,upper=4> DCd;
            vector<lower=0>[n_sigma] sigma;
        }
        model {
            vector[N] theta;
            vector[N] sigma_heter;
            theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m;   
            sigma_heter = model_matrix * sigma;
            target += normal_lpdf( beta_0 | 0, 10 );      
            target += normal_lpdf( beta_sex | 0, 10 );
            target += normal_lpdf( beta_c | 0, 10 );
            target += normal_lpdf( gamma | 1, 1 );
            target += uniform_lpdf( DCd | 0.25, 4);
            target += exponential_lpdf(sigma | 1);
            for(i in 1:N)
              target += normal_lpdf( y[i] | theta[i], sigma_heter[i] );  
        }"
        }
      }
      if(!is.null(covariate)){
        x<-COV
        cov_name<-paste("x",c(1:num_cov),sep="")
        coe_name<-paste("beta_",c(1:num_cov),sep="")
        model_matrix1 = matrix(c(ifelse(sex==0&genotype==0,1,0),
                                ifelse(sex==0&genotype==1,1,0),
                                ifelse(sex==0&genotype==2,1,0),
                                ifelse(sex==1&genotype==0,1,0),
                                ifelse(sex==1&genotype==1,1,0)),N,5)
        
        dataList <- data.frame(
                      y=data[,2], 
                      x = COV,
                      sex = sex,
                      gg_1 = gg_1,
                      gg_2 = gg_2,
                      gg_m = gg_m)

        colnames(dataList)[2:(1+num_cov)]<-c(cov_name)
        dataList<-as.list(dataList)
        dataList$N<-N
        dataList$n_sigma<-5
        dataList$model_matrix<-model_matrix1
        if(prior == "normal"){
          a<-"data {
                int<lower=0> N ;
                vector[N] y;
                vector[N] sex;
                vector[N] gg_1;
                vector[N] gg_2;
                vector[N] gg_m;
                int<lower=0> n_sigma;
                matrix[N,n_sigma] model_matrix;"
          for(i in 1:length(cov_name)){
            a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
          }
          a<-paste(a,"}",sep="")
          
          b<-"parameters {
                real beta_0;
                real beta_sex;
                real beta_c;
                real<lower=0,upper=2> gamma;
                real<lower=0.25,upper=4> DCd;
                vector<lower=0>[n_sigma] sigma;"
          for(i in 1:length(coe_name)){
            b<-paste(b,paste("real ",coe_name[i],";",sep=""))
          }
          b<-paste(b,"}",sep="")
          
          c<-"model {
                vector[N] theta;
                vector[N] sigma_heter;
                theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m"
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
          }
          c<-paste(c,";")
          c<-paste(c,"sigma_heter = model_matrix * sigma;
                      target += normal_lpdf( beta_0 | 0, 10 );      
                      target += normal_lpdf( beta_sex | 0, 10 );
                      target += normal_lpdf( beta_c | 0, 10 );
                      target += normal_lpdf( gamma | 1, 1 );
                      target += normal_lpdf( DCd | 2, 1 );
                      target += exponential_lpdf(sigma | 1);
                      for(i in 1:N)
                        target += normal_lpdf( y[i] | theta[i], sigma_heter[i] ); ",sep="\n  ")
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
          }
          c<-paste(c,"}",sep="")
          
          modelString=paste(a,b,c,sep="\n  ")
        }
        else if(prior == "uniform"){
          a<-"data {
                int<lower=0> N ;
                vector[N] y;
                vector[N] sex;
                vector[N] gg_1;
                vector[N] gg_2;
                vector[N] gg_m;
                int<lower=0> n_sigma;
                matrix[N,n_sigma] model_matrix;"
          for(i in 1:length(cov_name)){
            a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
          }
          a<-paste(a,"}",sep="")
          
          b<-"parameters {
                real beta_0;
                real beta_sex;
                real beta_c;
                real<lower=0,upper=2> gamma;
                real<lower=0.25,upper=4> DCd;
                vector<lower=0>[n_sigma] sigma;"
          for(i in 1:length(coe_name)){
            b<-paste(b,paste("real ",coe_name[i],";",sep=""))
          }
          b<-paste(b,"}",sep="")
          
          c<-"model {
                vector[N] theta;
                vector[N] sigma_heter;
                theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m"
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
          }
          c<-paste(c,";")
          c<-paste(c,"sigma_heter = model_matrix * sigma;
                      target += normal_lpdf( beta_0 | 0, 10 );      
                      target += normal_lpdf( beta_sex | 0, 10 );
                      target += normal_lpdf( beta_c | 0, 10 );
                      target += normal_lpdf( gamma | 1, 1 );
                      target += uniform_lpdf( DCd | 0.25, 4);
                      target += exponential_lpdf(sigma | 1);
                      for(i in 1:N)
                        target += normal_lpdf( y[i] | theta[i], sigma_heter[i] ); ",sep="\n  ")
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
          }
          c<-paste(c,"}",sep="")
          
          modelString=paste(a,b,c,sep="\n  ")
        }
      }
    }
    
    if(trait_type=="qualitative"){
      if(is.null(covariate)){
        
        dataList <- list( N=N,
                      y=data[,2], 
                      sex = sex,
                      gg_1 = gg_1,
                      gg_2 = gg_2,
                      gg_m = gg_m)
        
        if(prior == "normal"){
          modelString = "
        data {
            int<lower=0> N ;
            int y[N];
            vector[N] sex;
            vector[N] gg_1;
            vector[N] gg_2;
            vector[N] gg_m;
        }
        parameters {
            real beta_0;
            real beta_sex;
            real beta_c;
            real<lower=0,upper=2> gamma;
            real<lower=0.25,upper=4> DCd;
        }
        model {
            vector[N] theta;
            theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m;   
            target += normal_lpdf( beta_0 | 0, 10 );      
            target += normal_lpdf( beta_sex | 0, 10 );
            target += normal_lpdf( beta_c | 0, 10 );
            target += normal_lpdf( gamma | 1, 1 );
            target += normal_lpdf( DCd | 2, 1 );
            target += bernoulli_logit_lpmf( y | theta);  
        }"
        }
        else if(prior == "uniform"){
          modelString = "
        data {
            int<lower=0> N ;
            int y[N];
            vector[N] sex;
            vector[N] gg_1;
            vector[N] gg_2;
            vector[N] gg_m;
        }
        parameters {
            real beta_0;
            real beta_sex;
            real beta_c;
            real<lower=0,upper=2> gamma;
            real<lower=0.25,upper=4> DCd;
        }
        model {
            vector[N] theta;
            theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m;   
            target += normal_lpdf( beta_0 | 0, 10 );      
            target += normal_lpdf( beta_sex | 0, 10 );
            target += normal_lpdf( beta_c | 0, 10 );
            target += normal_lpdf( gamma | 1, 1 );
            target += uniform_lpdf( DCd | 0.25, 4);
            target += bernoulli_logit_lpmf( y | theta);  
        }"
        }
      }
      if(!is.null(covariate)){
        x<-COV
        cov_name<-paste("x",c(1:num_cov),sep="")
        coe_name<-paste("beta_",c(1:num_cov),sep="")
        
        dataList <- data.frame(
          y=data[,2], 
          x = COV,
          sex = sex,
          gg_1 = gg_1,
          gg_2 = gg_2,
          gg_m = gg_m)
        
        colnames(dataList)[2:(1+num_cov)]<-c(cov_name)
        dataList<-as.list(dataList)
        dataList$N<-N
        if(prior == "normal"){
          a<-"data {
                int<lower=0> N ;
                int y[N];
                vector[N] sex;
                vector[N] gg_1;
                vector[N] gg_2;
                vector[N] gg_m;"
          for(i in 1:length(cov_name)){
            a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
          }
          a<-paste(a,"}",sep="")
          
          b<-"parameters {
                real beta_0;
                real beta_sex;
                real beta_c;
                real<lower=0,upper=2> gamma;
                real<lower=0.25,upper=4> DCd;"
          for(i in 1:length(coe_name)){
            b<-paste(b,paste("real ",coe_name[i],";",sep=""))
          }
          b<-paste(b,"}",sep="")
          
          c<-"model {
                vector[N] theta;
                theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m"
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
          }
          c<-paste(c,";")
          c<-paste(c,"target += normal_lpdf( beta_0 | 0, 10 );      
                      target += normal_lpdf( beta_sex | 0, 10 );
                      target += normal_lpdf( beta_c | 0, 10 );
                      target += normal_lpdf( gamma | 1, 1 );
                      target += normal_lpdf( DCd | 2, 1 );
                      target += bernoulli_logit_lpmf( y | theta);",sep="\n  ")
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
          }
          c<-paste(c,"}",sep="")
          
          modelString=paste(a,b,c,sep="\n  ")
        }
        else if(prior == "uniform"){
          a<-"data {
                int<lower=0> N ;
                int y[N];
                vector[N] sex;
                vector[N] gg_1;
                vector[N] gg_2;
                vector[N] gg_m;"
          for(i in 1:length(cov_name)){
            a<-paste(a,paste("vector[N] ",cov_name[i],";",sep=""))
          }
          a<-paste(a,"}",sep="")
          
          b<-"parameters {
                real beta_0;
                real beta_sex;
                real beta_c;
                real<lower=0,upper=2> gamma;
                real<lower=0.25,upper=4> DCd;"
          for(i in 1:length(coe_name)){
            b<-paste(b,paste("real ",coe_name[i],";",sep=""))
          }
          b<-paste(b,"}",sep="")
          
          c<-"model {
                vector[N] theta;
                theta = beta_0 + beta_sex*sex + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m"
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("+",coe_name[i],"*",cov_name[i]))
          }
          c<-paste(c,";")
          c<-paste(c,"target += normal_lpdf( beta_0 | 0, 10 );      
                      target += normal_lpdf( beta_sex | 0, 10 );
                      target += normal_lpdf( beta_c | 0, 10 );
                      target += normal_lpdf( gamma | 1, 1 );
                      target += uniform_lpdf( DCd | 0.25, 4);
                      target += bernoulli_logit_lpmf( y | theta);",sep="\n  ")
          for(i in 1:length(coe_name)){
            c<-paste(c,paste("target += normal_lpdf( ",coe_name[i]," | 0, 10 );",sep=""))
          }
          c<-paste(c,"}",sep="")
          
          modelString=paste(a,b,c,sep="\n  ")
        }
      }
    }
    
    
    stanDso <- stan_model(model_code=modelString)
    Fit<-sampling( object=stanDso, data=dataList,
                   chains=chains_num, iter=iter_num, warmup=warmup_num, thin=1,control = list(adapt_delta = acceptance_rate))
    sam_chain <- extract( Fit, par=c("DCd"))
    
    Mode_DCd <- c( Mode_DCd, modeofHMC(sam_chain$DCd) )
    
    HPDI_DCd <- rbind( HPDI_DCd , HPDIofHMC(sam_chain$DCd) ) 
    
    
  }
  
  result <- cbind(Mode_DCd, HPDI_DCd)
  
  row.names(result) <- marker.name
  
  colnames(result) <- c("Point_Estimate","HPDI_Lower","HPDI_Upper")
  
  return(result)
  
}

