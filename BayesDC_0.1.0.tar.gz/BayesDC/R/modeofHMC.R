#' @title  A function to obtain the mode of the samples
#'
#' @description A function to obtain the mode of the samples.
#' @usage modeofHMC(sam_chain)
#'
#' @param sam_chain A vector contains the samples.
#'
#' @return The modeofHMC() returns a value.
#' @export
#'
#' @author Yi Zhang and Ji-Yuan Zhou
#' 
#' @examples
#' modeofHMC(runif(100,5,50))
#'
modeofHMC <- function(sam_chain){
  dd <- density(sam_chain)
  dd$x[which.max(dd$y)]
}
