#' BayesDC_2
#'
#' @param data1 The data of the phenotye and genotype
#'
#' @return  a table
#' @export
#'
#' @examples
#' library(BayesDC)
#' BayesDC_2(pop2)
BayesDC_2 <- function(data1=data1){

  library("rstan")
  # options(mc.cores = parallel::detectCores())
  # rstan_options(auto_write = TRUE)

  ############## mode

  modeofMCMC <- function(sam_chain){
    dd <- density(sam_chain)
    dd$x[which.max(dd$y)]
  }

  #############HPDI

  HDIofMCMC = function( sampleVec , credMass=0.95 ) {
    sortedsam = sort( sampleVec )
    nsamp <- length( sortedsam )
    gap = round( credMass * nsamp )
    nCIs = nsamp - gap
    init <- 1 : nCIs
    inds <- which.min(sortedsam[init + gap] - sortedsam[init])
    HDImin = sortedsam[ inds ]
    HDImax = sortedsam[ inds + gap ]
    HDIlim = c( HDImin , HDImax )
    return( HDIlim )
  }


  ##########stan#########
  bayes_DCd_u="
data {
  int<lower=0> N ;
  int y[N] ;
  vector[N] x;
  vector[N] sex;
  vector[N] gg_1;
  vector[N] gg_2;
  vector[N] gg_m;
}
parameters {
  real beta_0;
  real beta_sex;
  real beta_1;
  real beta_c;
  real<lower=0,upper=2> gamma;
  real<lower=0.25,upper=4> DCd;
}
model {
  vector[N] theta;
  theta = beta_0 + beta_sex*sex + beta_1*x + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m;   //计算均值向量
  target += normal_lpdf( beta_0 | 0, 10 );       // 指定各个未知参数的先验分布
  target += normal_lpdf( beta_sex | 0, 10 );
  target += normal_lpdf( beta_1 | 0, 10 );
  target += normal_lpdf( beta_c | 0, 10 );
  target += normal_lpdf( gamma | 1, 1 );
  target += uniform_lpdf( DCd | 0.25, 4);
  target += bernoulli_logit_lpmf( y | theta);  //计算每个个体的似然
}
"
################# trans ######################
bayes_DCd_u_compile <- stan_model( model_code=bayes_DCd_u )

############## uniform prior  #####################

bayes_uniform <- function(compile,data_list){

  ##stan outcome
  Fit_H1 <- sampling( object=compile, data=data_list,
                      chains=8, iter=3000, warmup=1000,control = list(adapt_delta = 0.99))
  sam_chain <- extract( Fit_H1, par=c("beta_0","beta_1","beta_sex", "beta_c","gamma","DCd"))

  ##mode
  U_Mode_DCd <- modeofMCMC(sam_chain$DCd)
  U_HPI_DCd <- HDIofMCMC(sam_chain$DCd)
  ##median
  U_Median_DCd <- quantile(sam_chain$DCd,probs=c(0.5,0.025,0.975))
  U_mean_DCd <- c(mean(sam_chain$DCd),
                  summary(Fit_H1)$summary[6,2],
                  sd(sam_chain$DCd))

  U_Mode_gamma <- modeofMCMC(sam_chain$gamma)
  U_HPI_gamma <- HDIofMCMC(sam_chain$gamma)
  U_Median_gamma <- quantile(sam_chain$gamma,probs=c(0.5,0.025,0.975))
  U_mean_gamma <- c(mean(sam_chain$gamma),
                    summary(Fit_H1)$summary[5,2],
                    sd(sam_chain$gamma))

  bayes_result<-list(mode=c(U_Mode_DCd,U_HPI_DCd),median=U_Median_DCd,
                     mean=U_mean_DCd,
                     RRR=(summary(Fit_H1)$summary)[,dim(summary(Fit_H1)$summary)[2]][6],
                     mode_gamma=c(U_Mode_gamma,U_HPI_gamma),median_gamma=U_Median_gamma,
                     mean_gamma=U_mean_gamma)

  return(bayes_result)
}


##################normal#############

bayes_DCd_nn="
data {
  int<lower=0> N ;
  int y[N] ;
  vector[N] x;
  vector[N] sex;
  vector[N] gg_1;
  vector[N] gg_2;
  vector[N] gg_m;
}
parameters {
  real beta_0;
  real beta_sex;
  real beta_1;
  real beta_c;
  real<lower=0,upper=2> gamma;
  real<lower=0.25,upper=4> DCd;
}
model {
  vector[N] theta;
  theta = beta_0 + beta_sex*sex + beta_1*x + beta_c*gamma*gg_1 + beta_c*(2-gamma)*gg_2 + beta_c*DCd*gg_m;   //计算均值向量
  target += normal_lpdf( beta_0 | 0, 10 );       // 指定各个未知参数的先验分布
  target += normal_lpdf( beta_sex | 0, 10 );
  target += normal_lpdf( beta_1 | 0, 10 );
  target += normal_lpdf( beta_c | 0, 10 );
  target += normal_lpdf( gamma | 1, 1 );
  target += normal_lpdf( DCd | 2, 1 );
  target += bernoulli_logit_lpmf( y | theta);  //计算每个个体的似然
}
"

#################  ######################
bayes_DCd_nn_compile <- stan_model( model_code=bayes_DCd_nn )

#########normal#########
bayes_norm <- function(compile,data_list){

  ##
  Fit_H1 <- sampling( object=compile, data=data_list,
                      chains=8, iter=3000, warmup=1000,control = list(adapt_delta = 0.99))
  sam_chain <- extract( Fit_H1, par=c("beta_0","beta_1","beta_sex", "beta_c","gamma","DCd"))

  ##
  Norm_Mode_DCd <- modeofMCMC(sam_chain$DCd)
  Norm_HPI_DCd <- HDIofMCMC(sam_chain$DCd)
  ##
  Norm_Median_DCd <- quantile(sam_chain$DCd,probs=c(0.5,0.025,0.975))
  Norm_mean_DCd <- c(mean(sam_chain$DCd),
                     summary(Fit_H1)$summary[6,2],
                     sd(sam_chain$DCd))

  Norm_Mode_gamma <- modeofMCMC(sam_chain$gamma)
  Norm_HPI_gamma <- HDIofMCMC(sam_chain$gamma)
  Norm_Median_gamma <- quantile(sam_chain$gamma,probs=c(0.5,0.025,0.975))
  Norm_mean_gamma <- c(mean(sam_chain$gamma),
                       summary(Fit_H1)$summary[5,2],
                       sd(sam_chain$gamma))

  bayes_result<-list(mode=c(Norm_Mode_DCd,Norm_HPI_DCd),median=Norm_Median_DCd,
                     mean=Norm_mean_DCd,
                     RRR=(summary(Fit_H1)$summary)[,dim(summary(Fit_H1)$summary)[2]][6],
                     mode_gamma=c(Norm_Mode_gamma,Norm_HPI_gamma),median_gamma=Norm_Median_gamma,
                     mean_gamma=Norm_mean_gamma)

  return(bayes_result)
}

data1_lm <- function(data1){

  ####phenotype and covariate#####
  phen<-data.frame(id=c(1:length(data1[,7])),disease=data1[,7],sex=data1[,5],x=data1[,9],gg_1=data1[,10],gg_2=data1[,11],gg_m=data1[,12])
  MM<-glm(disease ~ x+sex+gg_1+gg_2+gg_m, data=phen,family=gaussian)

  ncoef <- length(MM$coefficients)
  beta_hat <- MM$coefficients[(ncoef-2):ncoef]
  cov_hat <- vcov(MM)[(ncoef-2):ncoef,(ncoef-2):ncoef]
  mu_n <- beta_hat[3]
  mu_d <- (beta_hat[1]+beta_hat[2])/2
  var_n <- cov_hat[3,3]
  var_d <- (cov_hat[1,1]+cov_hat[2,2]+2*cov_hat[1,2])/4
  cov_nd <- (cov_hat[1,3]+cov_hat[2,3])/2
  rho <- cov_nd/sqrt(var_n*var_d)
  names(mu_n)=NULL
  names(mu_d)=NULL
  result<-list( mu_n,mu_d,var_n,var_d,rho)
  return(result)
}

output_result <- matrix(NA,nrow=1,ncol=62)
output_result <-- as.data.frame(output_result)
colnames(output_result) <- c(
                             "origin_p_Fieller","origin_Lower_CL_F","origin_Upper_CL_F","origin_CI_F",
                             "origin_length_CI_F","origin_CI_type_F",
                             "origin_p_PenFieller","origin_Lower_CL_PF","origin_Upper_CL_PF","origin_CI_PF",
                             "origin_length_CI_PF","origin_CI_type_PF",

                             "p_Fieller","Lower_CL_F","Upper_CL_F","CI_F","length_CI_F","CI_type_F",
                             "p_PenFieller","Lower_CL_PF","Upper_CL_PF","CI_PF","length_CI_PF","CI_type_PF",
                             "U_mode","U_HPDI_lower","U_HPDI_upper","U_median","U_PI_lower","U_PI_upper",
                             "U_mean","U_mean_se","U_mean_sd",
                             "U_mode_gamma","U_HPDI_lower_gamma","U_HPDI_upper_gamma",
                             "U_median_gamma","U_PI_lower_gamma","U_PI_upper_gamma",
                             "U_mean_gamma","U_mean_se_gamma","U_mean_sd_gamma",
                             "RRR_U",
                             "Norm_mode","Norm_HPDI_lower","Norm_HPDI_upper","Norm_median","Norm_PI_lower","Norm_PI_upper",
                             "Norm_mean","Norm_mean_se","Norm_mean_sd",
                             "Norm_mode_gamma","Norm_HPDI_lower_gamma","Norm_HPDI_upper_gamma",
                             "Norm_median_gamma","Norm_PI_lower_gamma","Norm_PI_upper_gamma",
                             "Norm_mean_gamma","Norm_mean_se_gamma","Norm_mean_sd_gamma",
                             "RRR_N")


#########association##############
hat<-data1_lm(data1)

mu_n <- hat[[1]]
mu_d <- hat[[2]]
var_n <- hat[[3]]
var_d <- hat[[4]]
rho <- hat[[5]]
#########Fieller计#########

Fieller_result <- Fieller(mu_n=mu_n,mu_d=mu_d,var_n=var_n,var_d=var_d,rho=rho,
                          truncation_interval=TRUE,truncation_lower=0.25,truncation_upper=4)


#########Pen Fieller#########
Penfieller_result <- PenFieller(mu_n=mu_n,mu_d=mu_d,var_n=var_n,var_d=var_d,rho=rho,
                                truncation_interval=TRUE,truncation_lower=0.25,truncation_upper=4)


##############Bayes data#########
bayes_DCd_u_data <- list(
  N = dim(data1)[1],
  y = data1[,7],
  x = data1[,9],
  sex = data1[,5],
  gg_1 = data1[,10],
  gg_2 = data1[,11],
  gg_m = data1[,12]
)
#####################
bayes_u_result <- bayes_uniform(bayes_DCd_u_compile,bayes_DCd_u_data)
bayes_norm_result <- bayes_uniform(bayes_DCd_nn_compile,bayes_DCd_u_data)

#########output #############
output_result <- c(
                   as.vector(Fieller_result[1,]),as.vector(Penfieller_result[1,]),
                   as.vector(Fieller_result[2,]),as.vector(Penfieller_result[2,]),
                   as.numeric(bayes_u_result$mode),as.numeric(bayes_u_result$median),
                   as.numeric(bayes_u_result$mean),
                   as.numeric(bayes_u_result$mode_gamma),as.numeric(bayes_u_result$median_gamma),
                   as.numeric(bayes_u_result$mean_gamma),
                   as.numeric(bayes_u_result$RRR),
                   as.numeric(bayes_norm_result$mode),as.numeric(bayes_norm_result$median),
                   as.numeric(bayes_norm_result$mean),
                   as.numeric(bayes_norm_result$mode_gamma),as.numeric(bayes_norm_result$median_gamma),
                   as.numeric(bayes_norm_result$mean_gamma),
                   as.numeric(bayes_norm_result$RRR))

return(output_result)

}

