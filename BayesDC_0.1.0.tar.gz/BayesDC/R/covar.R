#' @title A dataset of covariates.
#'
#' @description The pedigree information in the first five columns includes: pedigree ID (pid), individual ID (iid), father ID (fid), mother ID (mid) and sex. The six and seven is tow covariates.
#'
#' @docType data
#' @keywords datasets
#' @name covar
#' @usage covar
#' @format A dataset for 1,000 unrelated  subjects and seven variables contain two covariates.
#' \describe{
#' \item{FID}{Pedigree ID.}
#' \item{IID}{Individual ID.}
#' \item{PID}{Father ID.}
#' \item{MID}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{cov_1}{A numeric variable of continuous covariate.}
#' \item{cov_2}{A numeric variable of dichotomy covariate.}
#' }
NULL
